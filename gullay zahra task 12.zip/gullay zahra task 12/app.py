
from flask import Flask, render_template, request
from chatboot import get_response
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['question']
    response = get_response(user_input)
    return render_template('index.html', question=user_input, answer=response)

if __name__ == '__main__':
    app.run(debug=True)

